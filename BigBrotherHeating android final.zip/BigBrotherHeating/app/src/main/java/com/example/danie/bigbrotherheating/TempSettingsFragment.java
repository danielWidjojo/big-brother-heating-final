package com.example.danie.bigbrotherheating;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.NumberPicker;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the

 * to handle interaction events.
 * Use the {@link TempSettingsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TempSettingsFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    String TAG ="TempSettingsFragment";
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    FirestoreUpdate firestoreUpdate=new FirestoreUpdate("first_user","tempSettings",db);
    FirestoreUpdate firestoreUpdateHardwareOverride=new FirestoreUpdate("first_user","hardware_overide",db);
    Map<String,Object>tempHumIndoorOutdoor=new HashMap<>();
    Map<String,Object>tempHumIndoor=new HashMap<>();
    Map<String,Object>tempHumOutdoor=new HashMap<>();
    Map<String,Object>hardwareOverride=new HashMap<>();
    TextView indoorTempTextView;
    TextView outdoorTempTextView;
    NumberPicker currentTempNumberPicker;
    NumberPicker sleepTempNumberPicker;
    Switch intelligentModeSwitch;
    Boolean intelligentSwitchBoolean=false;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    //private OnFragmentInteractionListener mListener;

    public TempSettingsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SettingsFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static TempSettingsFragment newInstance(String param1, String param2) {
        TempSettingsFragment fragment = new TempSettingsFragment();
        Bundle args = new Bundle();
        //args.putString(ARG_PARAM1, param1);
        //args.putString(ARG_PARAM2, param2);
        //fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            DocumentReference docRef = db.collection("first_user").document("tempSettings");
            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            Log.d(TAG, "DocumentSnapshot data: " + document.getData());
                            //Toast.makeText(getContext(), String.valueOf(document.getData().get("setTemp")), Toast.LENGTH_LONG);
                        } else {
                            Log.d(TAG, "No such document");
                        }
                    } else {
                        Log.d(TAG, "get failed with ", task.getException());
                    }
                }
            });
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View returnView = inflater.inflate(R.layout.fragment_temp_settings, container, false);
        indoorTempTextView=(TextView)returnView.findViewById(R.id.indoorTempTextView);
        outdoorTempTextView=(TextView)returnView.findViewById(R.id.outdoorTempTextView);
        currentTempNumberPicker=(NumberPicker)returnView.findViewById(R.id.currentTempNumberPicker);
        sleepTempNumberPicker=(NumberPicker)returnView.findViewById(R.id.sleepTempNumberPicker);
        FloatingActionButton retryFloatButton=(FloatingActionButton)getActivity().findViewById(R.id.fab);
        intelligentModeSwitch=(Switch)returnView.findViewById(R.id.switchIntelligentMode);
        //Toast.makeText(getContext(), "Test", Toast.LENGTH_LONG);
        int currentSetTemp;
        Integer sleepSetTemp;

        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = getContext().registerReceiver(null, ifilter);
        // Are we charging / charged?
        int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        boolean isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL;
        //Toast.makeText(getContext(),"Power connection has been altered "+String.valueOf(isCharging), Toast.LENGTH_LONG).show();


        //Populate NumberPicker values from minimum and maximum value range
        //Set the minimum value of NumberPicker
        currentTempNumberPicker.setMinValue(5);
        //Specify the maximum value/number of NumberPicker
        currentTempNumberPicker.setMaxValue(30);

        //Gets whether the selector wheel wraps when reaching the min/max value.
        currentTempNumberPicker.setWrapSelectorWheel(true);
        //Prevent soft key value insert using keypad
        currentTempNumberPicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);

        //Set a value change listener for NumberPicker
        currentTempNumberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal){
                //Display the newly selected number from picker

                Map<String, Object> currentTemp = new HashMap<>();
                currentTemp.put("setTemp", newVal);
                firestoreUpdate.updateDb(currentTemp);

            }
        });
        //Populate NumberPicker values from minimum and maximum value range
        //Set the minimum value of NumberPicker
        sleepTempNumberPicker.setMinValue(5);
        //Specify the maximum value/number of NumberPicker
        sleepTempNumberPicker.setMaxValue(30);

        //Gets whether the selector wheel wraps when reaching the min/max value.
       sleepTempNumberPicker.setWrapSelectorWheel(true);
        //Prevent soft key value insert using keypad
        sleepTempNumberPicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);

        //Set a value change listener for NumberPicker
        sleepTempNumberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal){
                //Display the newly selected number from picker
                //indoorTempTextView.setText(String.valueOf(newVal));
                Map<String, Object> sleepTemp = new HashMap<>();
                sleepTemp.put("setSleepTemp", newVal);
                //fieldvalue to get server time stamp
                sleepTemp.put("updated", FieldValue.serverTimestamp());

                firestoreUpdate.updateDb(sleepTemp);
            }
        });
        retryFloatButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                Log.i(TAG, "onClick: ");
                // Access a Cloud Firestore instance from your Activity
            }

        });
        retryFloatButton.hide();
        intelligentModeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // do something, the isChecked will be
                // true if the switch is in the On position
                Map<String, Object> harwareOverride = new HashMap<>();
                harwareOverride.put("intelligentMode", isChecked);
                //fieldvalue to get server time stamp
                harwareOverride.put("updated", FieldValue.serverTimestamp());

                firestoreUpdateHardwareOverride.updateDb(harwareOverride);


            }
        });


        return returnView;
    }

    @Override
    public void onResume() {
        super.onResume();
        DocumentReference docRef = db.collection("first_user").document("tempSettings");
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d(TAG, "DocumentSnapshot data: " + document.getData());
                        currentTempNumberPicker.setValue(Integer.valueOf(String.valueOf(document.getData().get("setTemp"))));
                        sleepTempNumberPicker.setValue(Integer.valueOf(String.valueOf(document.getData().get("setSleepTemp"))));
                        //Toast.makeText(getContext(), String.valueOf(document.getData().get("setTemp")), Toast.LENGTH_LONG);

                    } else {
                        Log.d(TAG, "No such document");
                    }
                } else {
                    Log.d(TAG, "get failed with ", task.getException());
                }
            }
        });
        final DocumentReference docRef2 = db.collection("first_user").document("currentEnv");
        docRef2.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot snapshot,
                                @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w(TAG, "Listen failed.", e);
                    return;
                }

                if (snapshot != null && snapshot.exists()) {
                    Log.d(TAG, "Current data: " + snapshot.getData());
                    tempHumIndoorOutdoor=snapshot.getData();
                    tempHumIndoor= (Map<String, Object>) tempHumIndoorOutdoor.get("indoorEnv");
                    tempHumOutdoor=(Map<String, Object>) tempHumIndoorOutdoor.get("outdoorEnv");
                    Toast.makeText(getContext(), String.valueOf(tempHumIndoor.get("temp")), Toast.LENGTH_LONG);
                    indoorTempTextView.setText(String.valueOf(tempHumIndoor.get("temp"))+" C");
                    outdoorTempTextView.setText(String.valueOf(tempHumOutdoor.get("temp"))+" C");


                } else {
                    Log.d(TAG, "Current data: null");
                }
            }
        });

        final DocumentReference docRef3 = db.collection("first_user").document("hardware_overide");
        docRef3.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot snapshot,
                                @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w(TAG, "Listen failed.", e);
                    return;
                }

                if (snapshot != null && snapshot.exists()) {
                    Log.d(TAG, "Current data: " + snapshot.getData());
                    hardwareOverride=snapshot.getData();

                    intelligentSwitchBoolean= (Boolean)hardwareOverride.get("intelligentMode");
                    Boolean setHardwareOverrideBoolean= (Boolean)hardwareOverride.get("set");
                    Log.d(TAG,String.valueOf(intelligentSwitchBoolean));


                    if(intelligentSwitchBoolean){
                        intelligentModeSwitch.setChecked(true);
                    }else{
                        intelligentModeSwitch.setChecked(false);
                    }
                    if(!setHardwareOverrideBoolean){
                        intelligentModeSwitch.setClickable(true);
                    }else{
                        intelligentModeSwitch.setClickable(false);
                    }



                } else {
                    Log.d(TAG, "Current data: null");
                }
            }
        });


    }


}


    // TODO: Rename method, update argument and hook method into UI event
    /*
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }
    /*
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     *
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     *
     */
    /*
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
    */

