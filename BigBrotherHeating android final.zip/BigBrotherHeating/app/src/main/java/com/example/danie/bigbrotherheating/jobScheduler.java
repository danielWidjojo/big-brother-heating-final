package com.example.danie.bigbrotherheating;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.util.Log;

import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by danie on 24/10/2018.
 */

public class jobScheduler extends JobService {
    @Override
    public boolean onStartJob(final JobParameters jobParameters) {
        final String TAG="JobScheduler";

        new Thread(new Runnable() {
            public void run() {
                // a potentially time consuming task
                FirebaseFirestore db = FirebaseFirestore.getInstance();
                FirestoreUpdate firestoreUpdate=new FirestoreUpdate("first_user","currentStatus",db);
                Map<String, Object> sleepTemp = new HashMap<>();
                sleepTemp.put("atHome", false);
                //fieldvalue to get server time stamp
                sleepTemp.put("updated", FieldValue.serverTimestamp());

                firestoreUpdate.updateDb(sleepTemp);
            jobFinished(jobParameters,false);
            }
        }).start();
        Log.i(TAG, "onStartJob: job has started");

        return true;
    }



    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        return false;
    }
}
