package com.example.danie.bigbrotherheating;

import android.app.TimePickerDialog;
import android.content.Context;
import android.media.TimedText;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the

 * to handle interaction events.
 * Use the {@link SettingsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SettingsFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    FirebaseFirestore db=FirebaseFirestore.getInstance();
    FirestoreUpdate firestoreUpdate=new FirestoreUpdate("first_user","timeSettings",db);
    Map<String,Object>timeSettings=new HashMap<>();
    ArrayList<Integer>timeGoHomeArray=new ArrayList<>();
    ArrayList<Integer>timeGoToBedArray=new ArrayList<>();
    ArrayList<Integer>timeWakeUpArray=new ArrayList<>();
    String TAG="SettingsFragment";
     TextView time_go_home_textView;
    TextView time_wake_up_textView;
    TextView time_bed_textView;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    //private OnFragmentInteractionListener mListener;

    public SettingsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SettingsFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SettingsFragment newInstance(String param1, String param2) {
        SettingsFragment fragment = new SettingsFragment();
        Bundle args = new Bundle();
        //args.putString(ARG_PARAM1, param1);
        //args.putString(ARG_PARAM2, param2);
        //fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View returnView = inflater.inflate(R.layout.fragment_settings, container, false);
        CardView time_go_home_card_view=(CardView)returnView.findViewById(R.id.time_go_home_card_view);
        final CardView time_go_to_bed_card_view=(CardView)returnView.findViewById(R.id.time_bed_card_view);
        CardView time_wake_up_card_view=(CardView)returnView.findViewById(R.id.time_wake_up_card_view);
        time_go_home_textView=(TextView)returnView.findViewById(R.id.time_go_home_textView);
        time_wake_up_textView=(TextView)returnView.findViewById(R.id.time_wake_up_textView);
        time_bed_textView=(TextView)returnView.findViewById(R.id.time_bed_textView);


        time_go_home_card_view.setOnClickListener(new CardView.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Toast.makeText(getContext(),"Test",Toast.LENGTH_LONG).show();
                final TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(getContext(), new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        ArrayList <Integer> time=new ArrayList<Integer>();
                        time.add(selectedHour);
                        time.add(selectedMinute);
                        time_go_home_textView.setText(timeFormatter(time));
                        Map<String,Object> timeSet=new HashMap<>();
                        timeSet.put("timeGoHome",time);
                        timeSet.put("updated", FieldValue.serverTimestamp());
                        firestoreUpdate.updateDb(timeSet);
                        timeGoHomeArray.set(0,selectedHour);
                        timeGoHomeArray.set(1,selectedMinute);



                    }
                }, Integer.valueOf(String.valueOf(timeGoHomeArray.get(0))), Integer.valueOf(String.valueOf(timeGoHomeArray.get(1))),
                        false);//Yes 24 hour time
                mTimePicker.show();
            }
        });
        time_go_to_bed_card_view.setOnClickListener(new CardView.OnClickListener() {
            @Override
            public void onClick(View view) {
                final TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(getContext(), new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        ArrayList <Integer> time=new ArrayList<Integer>();
                        time.add(selectedHour);
                        time.add(selectedMinute);
                        time_bed_textView.setText(timeFormatter(time));
                        Map<String,Object> timeSet=new HashMap<>();
                        timeSet.put("timeGoToBed",time);
                        timeSet.put("updated", FieldValue.serverTimestamp());
                        firestoreUpdate.updateDb(timeSet);
                        timeGoToBedArray.set(0,selectedHour);
                        timeGoToBedArray.set(1,selectedMinute);


                    }
                }, Integer.valueOf(String.valueOf(timeGoToBedArray.get(0))), Integer.valueOf(String.valueOf(timeGoToBedArray.get(1)))
                        , false);//Yes 24 hour time
                mTimePicker.show();
            }
        });
        time_wake_up_card_view.setOnClickListener(new CardView.OnClickListener() {
            @Override
            public void onClick(View view) {
                final TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(getContext(), new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        ArrayList <Integer> time=new ArrayList<Integer>();
                        time.add(selectedHour);
                        time.add(selectedMinute);
                        time_wake_up_textView.setText(timeFormatter(time));
                        Map<String,Object> timeSet=new HashMap<>();
                        timeSet.put("timeWakeUp",time);
                        timeSet.put("updated", FieldValue.serverTimestamp());
                        firestoreUpdate.updateDb(timeSet);
                        timeWakeUpArray.set(0,selectedHour);
                        timeWakeUpArray.set(1,selectedMinute);

                    }
                },  Integer.valueOf(String.valueOf(timeWakeUpArray.get(0))), Integer.valueOf(String.valueOf(timeWakeUpArray.get(1)))
                        , false);//Yes 24 hour time
                mTimePicker.show();
            }
        });




        // Inflate the layout for this fragment
        return returnView;
    }

    @Override
    public void onStart() {
        super.onStart();
        DocumentReference docRef = db.collection("first_user").document("timeSettings");
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d(TAG, "DocumentSnapshot data: " + document.getData());
                        timeSettings=document.getData();
                        timeGoHomeArray=(ArrayList<Integer>) timeSettings.get("timeGoHome");
                        timeGoToBedArray=(ArrayList<Integer>) timeSettings.get("timeGoToBed");
                        timeWakeUpArray=(ArrayList<Integer>) timeSettings.get("timeWakeUp");
                        time_go_home_textView.setText(timeFormatter(timeGoHomeArray));
                        time_bed_textView.setText(timeFormatter(timeGoToBedArray));
                        time_wake_up_textView.setText(timeFormatter(timeWakeUpArray));
                        //Integer hour=Integer.valueOf(String.valueOf(timeGoHomeArray.get(0)));

                        //Toast.makeText(getContext(), String.valueOf(hour), Toast.LENGTH_LONG).show();
                    } else {
                        Log.d(TAG, "No such document");
                    }
                } else {
                    Log.d(TAG, "get failed with ", task.getException());
                }
            }
        });

    }

    public String timeFormatter(ArrayList<Integer> time){
        Integer hour=Integer.valueOf(String.valueOf(time.get(0)));
        Integer minute=Integer.valueOf(String.valueOf(time.get(1)));
        String amPm="";
        String formattedTime="";
        if (hour>=12){
            if (hour>=13){
                hour=hour-12;
            }
            amPm="PM";
        }else {
            if(hour<1){
                hour=hour+12;
            }
            amPm="AM";
        }
        String minuteString="00";
        if(minute<10){
            minuteString="0"+String.valueOf(minute);
        }else{
            minuteString=String.valueOf(minute);
        }
        formattedTime=String.valueOf(hour)+":"+minuteString+" "+amPm;
        return formattedTime;

    }
}


    // TODO: Rename method, update argument and hook method into UI event
    /*
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }
    /*
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     *
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     *
     */
    /*
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
    */

