package com.example.danie.bigbrotherheating;


import android.content.Context;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link TempHumFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TempHumFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    TextView currentTempView;
    TextView currentHumView;
    TextView avgTempView;
    TextView avgHumView;
    TextView maxTempView;
    TextView minTempView;
    TextView maxHumView;
    TextView minHumView;
    TextView clockView;
    TextView dateView;
    TextView heaterStatusView;
    NumberPicker modeNumberPicker;
    FloatingActionButton retryFloatButton;
    String TAG="testing";
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    FirestoreUpdate firestoreUpdate=new FirestoreUpdate("first_user","hardware_overide",db);

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;


    public TempHumFragment() {
        // Required empty public constructor
    }

    /*
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment TempHumFragment.
     */
    // TODO: Rename and change types and number of parameters
    /*
    public static TempHumFragment newInstance(String param1, String param2) {
        TempHumFragment fragment = new TempHumFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }
    */
    Map<String,Object>tempHumIndoorOutdoor=new HashMap<>();
    Map<String,Object>tempHumIndoor=new HashMap<>();
    Map<String,Object>tempHumOutdoor=new HashMap<>();
    Map<String,Object>hardwareOveride=new HashMap<>();
    Map<String,Object>heaterStatus=new HashMap<>();
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View returnView = inflater.inflate(R.layout.fragment_temp_hum, container, false);
        //Toast.makeText(getActivity(),"Message: "+mParam1,Toast.LENGTH_LONG).show();
        retryFloatButton=(FloatingActionButton)getActivity().findViewById(R.id.fab);
        currentTempView=(TextView) returnView.findViewById(R.id.currentTempView);
        currentHumView=(TextView) returnView.findViewById(R.id.currentHumView);
        avgTempView=(TextView) returnView.findViewById(R.id.avgTempView);
        avgHumView=(TextView) returnView.findViewById(R.id.avgHumView);
        minTempView=(TextView) returnView.findViewById(R.id.minTempView);
        maxTempView=(TextView) returnView.findViewById(R.id.maxTempView);
        minHumView=(TextView) returnView.findViewById(R.id.minHumView);
        maxHumView=(TextView) returnView.findViewById(R.id.maxHumView);
        clockView=(TextView) returnView.findViewById(R.id.clockView);
        dateView=(TextView) returnView.findViewById(R.id.dateView);
        heaterStatusView=(TextView)returnView.findViewById(R.id.heaterStatusText);

        modeNumberPicker=(NumberPicker) returnView.findViewById(R.id.modeNumberPicker);
        //currentTempView.setText("23"+ (char) 0x00B0+"C" );
        modeNumberPicker.setMinValue(1);
        modeNumberPicker.setMaxValue(3);
        modeNumberPicker.setDisplayedValues( new String[] { "Auto", "On", "Off" } );
        //Gets whether the selector wheel wraps when reaching the min/max value.
        modeNumberPicker.setWrapSelectorWheel(true);
        //Prevent soft key value insert using keypad
        modeNumberPicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        //Set a value change listener for NumberPicker
        modeNumberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal){
                //Display the newly selected number from picker
                //indoorTempTextView.setText(String.valueOf(newVal));
                int month = 8;
                Boolean setManualBoolean=false;
                Boolean setStatusBoolean=false;
                switch (newVal) {
                    case 1:
                        setManualBoolean =false;
                        break;
                    case 2:
                        setManualBoolean=true;
                        setStatusBoolean=true;
                        break;
                    case 3:
                        setManualBoolean=true;
                        setStatusBoolean=false;
                        break;
                }
                Map<String, Object> hardwareOveride = new HashMap<>();
                hardwareOveride.put("set", setManualBoolean);
                hardwareOveride.put("status", setStatusBoolean);
                //fieldvalue to get server time stamp
                hardwareOveride.put("updated", FieldValue.serverTimestamp());


                firestoreUpdate.updateDb(hardwareOveride);
            }
        });




        retryFloatButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                updatingClock();

                Log.i(TAG, "onClick: ");

                // Access a Cloud Firestore instance from your Activity

                /*

                Map<String, Object> city = new HashMap<>();
                city.put("set", false);
                city.put("status", false);
                //fieldvalue to get server time stamp
                city.put("updated", FieldValue.serverTimestamp());

                db.collection("first_user").document("hardware_overide")
                        .set(city)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Log.d(TAG, "DocumentSnapshot successfully written!");
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w(TAG, "Error writing document", e);
                            }
                        });
                        */







            }

        });



        return returnView;
}

    @Override
    public void onStart() {
        super.onStart();
        final DocumentReference docRef2 = db.collection("first_user").document("currentEnv");
        docRef2.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot snapshot,
                                @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w(TAG, "Listen failed.", e);
                    return;
                }

                if (snapshot != null && snapshot.exists()) {
                    Log.d(TAG, "Current data: " + snapshot.getData());
                    tempHumIndoorOutdoor=snapshot.getData();
                    tempHumIndoor= (Map<String, Object>) tempHumIndoorOutdoor.get("indoorEnv");
                    tempHumOutdoor= (Map<String, Object>) tempHumIndoorOutdoor.get("outdoorEnv");
                    //Toast.makeText(getContext(), String.valueOf(tempHumIndoor.get("temp")), Toast.LENGTH_LONG);
                    currentTempView.setText(String.valueOf(tempHumIndoor.get("temp"))+" C");
                    currentHumView.setText(String.valueOf(tempHumIndoor.get("hum"))+" %");
                    avgTempView.setText(String.valueOf(tempHumOutdoor.get("temp"))+" C");
                    avgHumView.setText(String.valueOf(tempHumOutdoor.get("hum"))+" %");
                    minTempView.setText(String.valueOf(tempHumOutdoor.get("tempMin"))+" C");
                    maxTempView.setText(String.valueOf(tempHumOutdoor.get("tempMax"))+" C");
                    minHumView.setText(String.valueOf(tempHumOutdoor.get("wind"))+"");
                    maxHumView.setText(String.valueOf(tempHumOutdoor.get("cloud"))+"");
                } else {
                    Log.d(TAG, "Current data: null");
                }
            }
        });
        // Access a Cloud Firestore instance from your Activity
        final DocumentReference docRef = db.collection("first_user").document("hardware_overide");
        docRef.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot snapshot,
                                @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w(TAG, "Listen failed.", e);
                    return;
                }

                if (snapshot != null && snapshot.exists()) {
                    //Toast.makeText(getContext(),"Current data"+snapshot.getData(), Toast.LENGTH_LONG).show();
                    Log.d(TAG, "Current data: " + snapshot.getData());
                    hardwareOveride=snapshot.getData();
                    Boolean set=(Boolean) hardwareOveride.get("set");
                    Boolean status=(Boolean) hardwareOveride.get("status");
                    if(set==false){
                        modeNumberPicker.setValue(1);
                    }else {
                        if(status==true)    {
                            modeNumberPicker.setValue(2);
                        }else{
                            modeNumberPicker.setValue(3);
                        }
                    }

                } else {
                    Log.d(TAG, "Current data: null");
                }
            }
        });
        // Access a Cloud Firestore instance from your Activity
        final DocumentReference docRef3 = db.collection("first_user").document("heaterStatus");
        docRef3.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot snapshot,
                                @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w(TAG, "Listen failed.", e);
                    return;
                }

                if (snapshot != null && snapshot.exists()) {
                    //Toast.makeText(getContext(),"Current data"+snapshot.getData(), Toast.LENGTH_LONG).show();
                    Log.d(TAG, "Current data: " + snapshot.getData());

                    heaterStatus=snapshot.getData();
                    Boolean heaterStatusBoolean=(Boolean) heaterStatus.get("heaterIsOn");
                    if(heaterStatusBoolean){
                        heaterStatusView.setText("Heater is On");
                    }else{
                        heaterStatusView.setText("Heater is Off");
                    }




                } else {
                    Log.d(TAG, "Current data: null");
                }
            }
        });
        retryFloatButton.hide();
    }

    @Override
    public void onResume() {
        super.onResume();
        //tempHumTcpComm(mParam1,currentTempView,currentHumView,avgTempView,avgHumView,maxTempView,
        //minTempView,maxHumView,minHumView,retryFloatButton);
        updatingClock();
        //for commented will be figured out later
        //((MainActivity) getActivity()).setActionBarTitle(mParam1);}
    }



    public void updatingClock(){
        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("EEE, dd MMM");
        SimpleDateFormat tf = new SimpleDateFormat("hh:mm aa");
        String currentTimeString = tf.format(c.getTime());
        String currentDateString = df.format(c.getTime());
        clockView.setText(currentTimeString);
        dateView.setText(currentDateString);
    }
}
