package com.example.danie.bigbrotherheating;

import android.support.annotation.NonNull;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by danie on 13/10/2018.
 */

public class FirestoreUpdate {
    public String document;
    public String root;

    public FirebaseFirestore db;
    public String TAG="test";



    public FirestoreUpdate(String startRoot, String startDocument,  FirebaseFirestore dbInstance) {
        root = startRoot;
        document=startDocument;

        db=dbInstance;
    }

    public void updateDb(Map<String,Object> mapData) {

        db.collection(root).document(document).update(mapData)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully written!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });

    }
    // How to make a function that returns a value from eventlistener??


}
